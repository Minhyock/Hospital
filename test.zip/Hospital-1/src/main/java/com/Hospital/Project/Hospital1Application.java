package com.Hospital.Project;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@MapperScan("com.Hospital.Project.VO")
@SpringBootApplication
public class Hospital1Application {

	public static void main(String[] args) {
		SpringApplication.run(Hospital1Application.class, args);
	}

}
