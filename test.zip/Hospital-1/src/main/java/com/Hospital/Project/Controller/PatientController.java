package com.Hospital.Project.Controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import com.Hospital.Project.DTO.Patient;
import com.Hospital.Project.VO.PatientDAO;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class PatientController {

	private static final Logger logger = LoggerFactory.getLogger(PatientController.class);

	@Autowired
	PatientDAO dao;

	// 기본화면
	@GetMapping("/home")
	public String home(HttpServletRequest request) {
		System.out.println("h");
		return "patient/home";
	}

	// 정보 입력창으로 이동
	@GetMapping("/insert")
	public String insert() {
		System.out.println("i");
		return "patient/insert";
	}

	// 입력 처리 (사용자가 입력한 걸 DB로)
	@PostMapping("/insert")
	public String insert(Patient patient) {
		logger.info("전달된 값:{}", patient);
		dao.insert(patient);
		return "patient/complete";
	}
	
	// 완료 페이지 확인용
	@GetMapping("/complete")
	public String complete() {
		System.out.println("k");
		return "patient/complete";
	}
}
