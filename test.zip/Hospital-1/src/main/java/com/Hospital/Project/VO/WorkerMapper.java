package com.Hospital.Project.VO;

import org.apache.ibatis.annotations.Mapper;

import com.Hospital.Project.DTO.Worker;

@Mapper
public interface WorkerMapper {

	int insert(Worker worker);

	Worker getWorker(String WN);

	int updateworker(Worker worker);

	int deleteworker(Worker worker);

}
