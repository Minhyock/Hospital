package com.Hospital.Project.VO;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Hospital.Project.DTO.Patient;

@Repository
public class PatientDAO {
	private static final Logger logger = LoggerFactory.getLogger(PatientDAO.class);
	
	@Autowired
	SqlSession sqlSession;
	
	public int insert(Patient patient) {
	    PatientMapper mapper = sqlSession.getMapper(PatientMapper.class);
	    logger.info("controller에서 전달된 값:{}", patient);
	    int result = mapper.insert(patient);
	    
	    logger.info("새로 추가된 레코드 : {}", result);
	    return result;
	}
}