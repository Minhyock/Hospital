package com.Hospital.Project.VO;

import com.Hospital.Project.DTO.Patient;

public interface PatientMapper {
    int insert(Patient patient);
}