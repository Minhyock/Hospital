package com.Hospital.Project.DTO;

public class Patient {
	int PN;
	String first_name;
	String last_name;
	int age;
	String sex;
	String job;
	String visit;
	String hurt;

	public Patient() {
		
	}
	
	public Patient(int pN, String first_name, String last_name, int age, String sex, String job, String visit,
			String hurt) {
		PN = pN;
		this.first_name = first_name;
		this.last_name = last_name;
		this.age = age;
		this.sex = sex;
		this.job = job;
		this.visit = visit;
		this.hurt = hurt;
	}

	public int getPN() {
		return PN;
	}
	public void setPN(int pN) {
		PN = pN;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getVisit() {
		return visit;
	}
	public void setVisit(String visit) {
		this.visit = visit;
	}
	public String getHurt() {
		return hurt;
	}
	public void setHurt(String hurt) {
		this.hurt = hurt;
	}

}
