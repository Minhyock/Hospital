package com.Hospital.Project.VO;

//import org.apache.ibatis.session.SqlSession;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Repository;

// import com.Hospital.Project.DTO.Worker;

// @Repository
// public class WorkerDAO {

//	@Autowired
//	SqlSession sqlSession;
	
	// 직원 등록
//	public int insert(Worker worker) {
//		WorkerMapper mapper = sqlSession.getMapper(WorkerMapper.class);
//		int result = 0;
//		
//		result = mapper.insert(worker);
//		return result; 
//	}
//	
//	// 로그인
//	public Worker getWorker(String WN) {
//		WorkerMapper mapper = sqlSession.getMapper(WorkerMapper.class);
//		Worker result = null; 
//		
//		result = mapper.getWorker(WN);
//		return result; 
//	
//	}
//	
//	// 정보 수정
//	public int updateWorker(Worker worker) {
//	    WorkerMapper mapper = sqlSession.getMapper(WorkerMapper.class);
//	    int result = 0;
//	    
//	    result = mapper.updateworker(worker);
//		return result;
//	}
//	
//	// 삭제
//	public int deleteWorker(Worker worker) {
//		WorkerMapper mapper = sqlSession.getMapper(WorkerMapper.class);
//		int result = 0;
//		
//		result = mapper.deleteworker(worker);
//		return result;
//	}
// }