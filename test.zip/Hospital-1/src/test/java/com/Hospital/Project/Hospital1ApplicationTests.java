package com.Hospital.Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hospital1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
